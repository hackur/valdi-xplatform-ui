/**
 * Testing utilities for Valdi AI UI
 * Export all testing helpers and mocks
 */

// test-utils has been removed due to TypeScript compilation errors
// TODO: Re-implement when testing dependencies are available
// export * from './test-utils';

export * from './MockNavigationController';
